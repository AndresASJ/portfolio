import asyncio

import pygame

from board import ChessBoard
from constants import BLACK, BLUE, BOARD_SIZE, HEIGHT, SQUARE_SIZE, WIDTH
from gui import draw_board, draw_status, restart_button_rect


pygame.init()


async def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("ASJ's PythonChess")
    clock = pygame.time.Clock()
    board = ChessBoard()
    game_result = None
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                board = ChessBoard()
                game_result = None

            if (
                event.type == pygame.MOUSEBUTTONDOWN
                and restart_button_rect().collidepoint(event.pos)
            ):
                board = ChessBoard()
                game_result = None
                continue

            if (
                not game_result
                and event.type == pygame.MOUSEBUTTONDOWN
                and event.pos[1] < BOARD_SIZE
            ):
                col = event.pos[0] // SQUARE_SIZE
                row = event.pos[1] // SQUARE_SIZE

                if board.selected_piece:
                    start = board.selected_piece
                    end = (row, col)
                    if board.make_move(start, end):
                        board.valid_moves = []
                        current_color = board.current_player
                        if board.is_checkmate(current_color):
                            winner = "Black" if current_color == BLUE else "White"
                            game_result = f"Checkmate — {winner} wins"
                        elif board.is_stalemate(current_color):
                            game_result = "Draw — stalemate"
                    else:
                        piece = board.board[row][col]
                        if piece and piece.color == board.current_player:
                            board.selected_piece = (row, col)
                            board.valid_moves = board.get_valid_moves(row, col)
                        else:
                            board.selected_piece = None
                            board.valid_moves = []
                else:
                    piece = board.board[row][col]
                    if piece and piece.color == board.current_player:
                        board.selected_piece = (row, col)
                        board.valid_moves = board.get_valid_moves(row, col)

        screen.fill(BLACK)
        draw_board(screen, board)
        draw_status(screen, board, game_result)
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)  # Yield to the browser's WebAssembly event loop.

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
