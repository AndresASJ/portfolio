# Window and board sizing
WIDTH = 720
BOARD_SIZE = 720
STATUS_HEIGHT = 96
HEIGHT = BOARD_SIZE + STATUS_HEIGHT
ROWS, COLS = 8, 8
SQUARE_SIZE = BOARD_SIZE // COLS

# Portfolio-inspired board palette
WHITE = (246, 241, 231)
BLACK = (22, 22, 25)
GRAY = (170, 132, 102)
DARK_SQUARE = (107, 76, 64)
RED = (34, 34, 38)       # Black chess pieces (kept for engine compatibility)
BLUE = (247, 242, 232)   # White chess pieces (kept for engine compatibility)
GREEN = (219, 87, 57)
YELLOW = (241, 188, 92)
MUTED = (172, 167, 157)
