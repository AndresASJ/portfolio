import pygame

from constants import (
    ROWS,
    COLS,
    SQUARE_SIZE,
    WHITE,
    BLACK,
    GRAY,
    DARK_SQUARE,
    RED,
    BLUE,
    GREEN,
    YELLOW,
    MUTED,
    WIDTH,
    HEIGHT,
    BOARD_SIZE,
)


def draw_board(screen, board):
    piece_font = pygame.font.Font(None, 54)
    coordinate_font = pygame.font.Font(None, 20)

    for row in range(ROWS):
        for col in range(COLS):
            color = GRAY if (row + col) % 2 == 0 else DARK_SQUARE
            square = pygame.Rect(
                col * SQUARE_SIZE,
                row * SQUARE_SIZE,
                SQUARE_SIZE,
                SQUARE_SIZE,
            )
            pygame.draw.rect(screen, color, square)

            piece = board.board[row][col]
            if piece:
                center = square.center
                pygame.draw.circle(screen, piece.color, center, SQUARE_SIZE // 3)
                outline = BLACK if piece.color == BLUE else WHITE
                pygame.draw.circle(screen, outline, center, SQUARE_SIZE // 3, 2)
                text_color = BLACK if piece.color == BLUE else WHITE
                text = piece_font.render(piece.symbol, True, text_color)
                screen.blit(text, text.get_rect(center=center))

            coordinate_color = WHITE if color == DARK_SQUARE else BLACK
            if col == 0:
                rank = coordinate_font.render(str(8 - row), True, coordinate_color)
                screen.blit(rank, (5, row * SQUARE_SIZE + 4))
            if row == 7:
                file_label = coordinate_font.render(
                    chr(ord("a") + col), True, coordinate_color
                )
                screen.blit(
                    file_label,
                    (col * SQUARE_SIZE + SQUARE_SIZE - 15, BOARD_SIZE - 20),
                )

    if board.selected_piece:
        selected_row, selected_col = board.selected_piece
        selected_square = pygame.Rect(
            selected_col * SQUARE_SIZE,
            selected_row * SQUARE_SIZE,
            SQUARE_SIZE,
            SQUARE_SIZE,
        )
        pygame.draw.rect(screen, GREEN, selected_square, 5)

        for move_row, move_col in board.valid_moves:
            center = (
                move_col * SQUARE_SIZE + SQUARE_SIZE // 2,
                move_row * SQUARE_SIZE + SQUARE_SIZE // 2,
            )
            if board.board[move_row][move_col]:
                pygame.draw.circle(screen, YELLOW, center, SQUARE_SIZE // 3 + 7, 5)
            else:
                pygame.draw.circle(screen, YELLOW, center, 11)


def restart_button_rect():
    return pygame.Rect(WIDTH - 154, BOARD_SIZE + 24, 130, 48)


def draw_status(screen, board, game_result=None):
    pygame.draw.rect(screen, BLACK, (0, BOARD_SIZE, WIDTH, HEIGHT - BOARD_SIZE))
    label_font = pygame.font.Font(None, 24)
    status_font = pygame.font.Font(None, 34)

    label = label_font.render("ASJ'S PYTHONCHESS  /  BROWSER EDITION", True, MUTED)
    screen.blit(label, (24, BOARD_SIZE + 17))

    if game_result:
        status = game_result
        status_color = YELLOW
    else:
        player = "White" if board.current_player == BLUE else "Black"
        status = f"{player} to move"
        status_color = WHITE
        if board.is_check(board.current_player):
            status += "  —  check"
            status_color = YELLOW

    text = status_font.render(status, True, status_color)
    screen.blit(text, (24, BOARD_SIZE + 48))

    button = restart_button_rect()
    pygame.draw.rect(screen, GREEN, button, border_radius=6)
    button_text = label_font.render("NEW GAME  [R]", True, WHITE)
    screen.blit(button_text, button_text.get_rect(center=button.center))
